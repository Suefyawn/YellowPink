/* Yellow Pink — Blog Pages */

const BLOG_POSTS = [
  {
    slug: 'melasma-guide',
    title: 'The Complete Guide to Treating Melasma in Pakistan',
    excerpt: 'Everything you need to know about melasma triggers, treatments, and the ingredients that actually work for South Asian skin.',
    category: 'Skincare',
    date: 'Apr 28, 2026',
    readTime: '8 min read',
    featured: true,
  },
  {
    slug: 'rhodelip-tints-review',
    title: 'Rhode Peptide Lip Tints: Honest Review After 30 Days',
    excerpt: 'We tested every shade — Raspberry Jelly, Espresso, Ribbon, and Taupe. Here\'s what\'s worth it and what\'s not.',
    category: 'Makeup',
    date: 'Apr 21, 2026',
    readTime: '5 min read',
  },
  {
    slug: 'fertility-supplements',
    title: 'Fertility Supplements: What the Science Actually Says',
    excerpt: 'A no-nonsense breakdown of the vitamins, minerals, and nutraceuticals with real clinical evidence behind them.',
    category: 'Wellness',
    date: 'Apr 14, 2026',
    readTime: '10 min read',
    featured: true,
  },
  {
    slug: 'spf-myths',
    title: '5 SPF Myths Pakistani Women Still Believe',
    excerpt: 'Dark skin doesn\'t need SPF? Indoor means safe? We bust the myths that are aging your skin faster.',
    category: 'Skincare',
    date: 'Apr 7, 2026',
    readTime: '4 min read',
  },
  {
    slug: 'cerave-vs-dupes',
    title: 'CeraVe vs Local Dupes: Lab-Tested Comparison',
    excerpt: 'We sent both to a lab. The results might surprise you — or confirm what you already suspected.',
    category: 'Skincare',
    date: 'Mar 30, 2026',
    readTime: '7 min read',
  },
  {
    slug: 'mens-health-taboo',
    title: 'Breaking the Taboo Around Men\'s Health in Pakistan',
    excerpt: 'Vitality, fertility, and wellness aren\'t just women\'s topics. Why more Pakistani men are taking their health seriously.',
    category: 'Wellness',
    date: 'Mar 22, 2026',
    readTime: '6 min read',
  },
];
window.__BLOG_POSTS = BLOG_POSTS;

/* ── Blog Listing Page ── */
const BlogPage = ({ onPostClick }) => {
  const [activeFilter, setActiveFilter] = React.useState('All');
  const filters = ['All', 'Skincare', 'Makeup', 'Wellness'];
  const featured = BLOG_POSTS.find(p => p.featured);
  const filtered = (activeFilter === 'All' ? BLOG_POSTS : BLOG_POSTS.filter(p => p.category === activeFilter));

  return (
    <div>
      {/* Header */}
      <section style={{ padding: '48px 0', borderBottom: '1px solid var(--line)' }}>
        <div className="container">
          <Overline style={{ display: 'block', marginBottom: 8, color: 'var(--ink-500)' }}>Journal</Overline>
          <h1 className="display-l" style={{ fontSize: '2.5rem', marginBottom: 12 }}>
            The Edit
          </h1>
          <p className="body-text" style={{ color: 'var(--ink-700)', maxWidth: 480 }}>
            Expert guides, honest reviews, and the science behind beauty and health — no fluff.
          </p>
        </div>
      </section>

      {/* Featured post */}
      {featured && (
        <section style={{ padding: 'var(--section-gap) 0', borderBottom: '1px solid var(--line)' }}>
          <div className="container">
            <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 0.8fr', gap: 48, alignItems: 'center', cursor: 'pointer' }}
              className="duo-grid"
              onClick={() => onPostClick && onPostClick(featured)}
            >
              <div className="img-placeholder" style={{ aspectRatio: '16/10', borderRadius: 'var(--radius-card)' }}>
                <span>featured article hero image</span>
              </div>
              <div>
                <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 12 }}>
                  <span style={{
                    padding: '3px 10px', background: 'var(--brand-yellow)', borderRadius: 'var(--radius-pill)',
                    fontSize: '0.6875rem', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase',
                  }}>Featured</span>
                  <Overline style={{ color: 'var(--ink-500)' }}>{featured.category}</Overline>
                </div>
                <h2 style={{
                  fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 500,
                  letterSpacing: '-0.02em', lineHeight: 1.15, marginBottom: 12,
                }}>{featured.title}</h2>
                <p className="body-text" style={{ color: 'var(--ink-700)', marginBottom: 16 }}>
                  {featured.excerpt}
                </p>
                <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
                  <span className="small-text">{featured.date}</span>
                  <span style={{ width: 3, height: 3, borderRadius: '50%', background: 'var(--ink-500)' }}></span>
                  <span className="small-text">{featured.readTime}</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Filter + posts grid */}
      <section style={{ padding: 'var(--section-gap) 0' }}>
        <div className="container">
          <div style={{ display: 'flex', gap: 12, marginBottom: 40 }}>
            {filters.map(f => (
              <button key={f} onClick={() => setActiveFilter(f)}
                style={{
                  padding: '8px 16px', borderRadius: 'var(--radius-pill)',
                  border: '1px solid ' + (activeFilter === f ? 'var(--ink-900)' : 'var(--line)'),
                  background: activeFilter === f ? 'var(--ink-900)' : 'transparent',
                  color: activeFilter === f ? 'var(--paper)' : 'var(--ink-700)',
                  fontFamily: 'var(--font-ui)', fontSize: '0.8125rem', fontWeight: 500,
                  cursor: 'pointer', transition: 'all 150ms ease-out',
                }}
              >{f}</button>
            ))}
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 'var(--gutter)' }} className="blog-grid">
            {filtered.map((post, i) => (
              <article key={i} style={{ cursor: 'pointer' }}
                onClick={() => onPostClick && onPostClick(post)}
              >
                <div className="img-placeholder" style={{
                  aspectRatio: '16/10', borderRadius: 'var(--radius-card)', marginBottom: 16,
                  transition: 'transform 200ms ease-out',
                }}
                  onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-2px)'}
                  onMouseLeave={e => e.currentTarget.style.transform = 'translateY(0)'}
                >
                  <span>article image</span>
                </div>
                <Overline style={{ color: 'var(--ink-500)', display: 'block', marginBottom: 6 }}>{post.category}</Overline>
                <h3 style={{
                  fontSize: '1.125rem', fontWeight: 600, letterSpacing: '-0.01em',
                  lineHeight: 1.3, marginBottom: 8,
                }}>{post.title}</h3>
                <p className="small-text" style={{ marginBottom: 8, lineHeight: 1.5 }}>{post.excerpt}</p>
                <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                  <span className="small-text" style={{ fontSize: '0.75rem' }}>{post.date}</span>
                  <span style={{ width: 3, height: 3, borderRadius: '50%', background: 'var(--ink-500)' }}></span>
                  <span className="small-text" style={{ fontSize: '0.75rem' }}>{post.readTime}</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

/* ── Blog Post Page ── */
const BlogPostPage = ({ post, onBack }) => {
  if (!post) return null;

  const relatedPosts = BLOG_POSTS.filter(p => p.slug !== post.slug && p.category === post.category).slice(0, 2);
  const relatedProducts = (window.__ALL_PRODUCTS || [])
    .filter(p => {
      if (post.category === 'Wellness') return p.category === 'Wellness';
      if (post.category === 'Skincare') return ['Skincare', 'Sunscreen'].includes(p.category);
      return ['Lip Tints', 'Blush', 'Foundations', 'Concealers', 'Highlighters'].includes(p.category);
    }).slice(0, 3);

  return (
    <div>
      {/* Breadcrumb */}
      <div className="container" style={{ padding: '16px var(--side)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <button onClick={onBack} style={{
            background: 'none', border: 'none', cursor: 'pointer',
            fontFamily: 'var(--font-ui)', fontSize: '0.8125rem', color: 'var(--ink-500)',
          }}>Journal</button>
          <span style={{ color: 'var(--ink-500)', fontSize: '0.75rem' }}>/</span>
          <span style={{ fontSize: '0.8125rem', color: 'var(--ink-900)' }}>{post.category}</span>
        </div>
      </div>

      {/* Article header */}
      <article style={{ borderTop: '1px solid var(--line)' }}>
        <div className="container" style={{ maxWidth: 800, padding: '48px var(--side) 0' }}>
          <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 16 }}>
            <Overline style={{ color: 'var(--ink-500)' }}>{post.category}</Overline>
            <span style={{ width: 3, height: 3, borderRadius: '50%', background: 'var(--ink-500)' }}></span>
            <span className="small-text">{post.readTime}</span>
          </div>
          <h1 style={{
            fontFamily: 'var(--font-display)', fontSize: '2.75rem', fontWeight: 500,
            letterSpacing: '-0.025em', lineHeight: 1.1, marginBottom: 16,
          }}>{post.title}</h1>
          <p className="body-text" style={{ color: 'var(--ink-700)', fontSize: '1.0625rem', lineHeight: 1.6, marginBottom: 24 }}>
            {post.excerpt}
          </p>
          <div style={{ display: 'flex', gap: 16, alignItems: 'center', paddingBottom: 32, borderBottom: '1px solid var(--line)' }}>
            <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'var(--paper2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <span style={{ fontSize: '0.75rem', fontWeight: 600 }}>YP</span>
            </div>
            <div>
              <div style={{ fontSize: '0.8125rem', fontWeight: 600 }}>Yellow Pink Editorial</div>
              <div className="small-text">{post.date}</div>
            </div>
          </div>
        </div>

        {/* Hero image */}
        <div className="container" style={{ maxWidth: 960, padding: '32px var(--side)' }}>
          <div className="img-placeholder" style={{ aspectRatio: '16/9', borderRadius: 'var(--radius-card)' }}>
            <span>article hero image</span>
          </div>
        </div>

        {/* Article body */}
        <div className="container" style={{ maxWidth: 680, padding: '0 var(--side) 48px' }}>
          <div style={{ lineHeight: 1.8, color: 'var(--ink-700)' }}>
            <p className="body-text" style={{ marginBottom: 20, fontSize: '0.9375rem', lineHeight: 1.8 }}>
              When we talk about skincare in Pakistan, the conversation usually starts and ends with fairness creams. But real skincare — the kind that transforms your skin long-term — is about understanding your specific concerns and choosing ingredients backed by clinical evidence.
            </p>
            <h2 className="h2" style={{ marginBottom: 12, marginTop: 40 }}>Understanding the Root Cause</h2>
            <p className="body-text" style={{ marginBottom: 20, fontSize: '0.9375rem', lineHeight: 1.8 }}>
              Whether it's melasma triggered by hormonal shifts, acne from a compromised moisture barrier, or hyperpigmentation from years of unprotected sun exposure — each condition has a different pathway. And each requires a different approach.
            </p>

            {/* Pull quote */}
            <blockquote style={{
              margin: '40px 0', padding: '24px 32px',
              background: 'var(--brand-yellow)', borderRadius: 'var(--radius-card)',
              position: 'relative',
            }}>
              <p style={{
                fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 500,
                fontStyle: 'italic', color: 'var(--ink-900)', lineHeight: 1.4, margin: 0,
              }}>
                "The best skincare routine is the one you'll actually follow. Consistency beats complexity every time."
              </p>
            </blockquote>

            <h2 className="h2" style={{ marginBottom: 12, marginTop: 40 }}>The Ingredients That Work</h2>
            <p className="body-text" style={{ marginBottom: 20, fontSize: '0.9375rem', lineHeight: 1.8 }}>
              We've curated every product in our catalog based on ingredient efficacy. Niacinamide for texture. Salicylic acid for breakouts. Kojic acid and glutathione for pigmentation. SPF 46+ for daily protection. No fillers, no false promises.
            </p>
            <p className="body-text" style={{ marginBottom: 20, fontSize: '0.9375rem', lineHeight: 1.8 }}>
              And for internal health — the nutraceuticals we carry are pharmaceutical-grade, with dosages and formulations that match international clinical standards. Because beauty isn't just topical. It's systemic.
            </p>

            <h2 className="h2" style={{ marginBottom: 12, marginTop: 40 }}>Building Your Routine</h2>
            <p className="body-text" style={{ fontSize: '0.9375rem', lineHeight: 1.8 }}>
              Start simple: cleanser, active treatment, moisturizer, SPF. That's it. Don't layer seven serums. Don't switch products every week. Find what works, give it 6–8 weeks, and trust the process.
            </p>
          </div>
        </div>

        <hr className="hairline" />

        {/* Mentioned products */}
        {relatedProducts.length > 0 && (
          <section style={{ padding: '48px 0' }}>
            <div className="container">
              <Overline style={{ display: 'block', marginBottom: 24 }}>Mentioned in This Article</Overline>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 'var(--gutter)' }} className="product-grid-3">
                {relatedProducts.map((p, i) => <ProductTile key={i} {...p} />)}
              </div>
            </div>
          </section>
        )}

        <hr className="hairline" />

        {/* Related articles */}
        {relatedPosts.length > 0 && (
          <section style={{ padding: '48px 0' }}>
            <div className="container">
              <Overline style={{ display: 'block', marginBottom: 24 }}>More from {post.category}</Overline>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 'var(--gutter)' }} className="duo-grid">
                {relatedPosts.map((rp, i) => (
                  <article key={i} style={{ cursor: 'pointer' }} onClick={() => onBack && onBack('blog-post', rp)}>
                    <div className="img-placeholder" style={{ aspectRatio: '16/10', borderRadius: 'var(--radius-card)', marginBottom: 12 }}>
                      <span>article image</span>
                    </div>
                    <Overline style={{ color: 'var(--ink-500)', display: 'block', marginBottom: 4 }}>{rp.category}</Overline>
                    <h3 className="h3" style={{ marginBottom: 4 }}>{rp.title}</h3>
                    <span className="small-text">{rp.date} · {rp.readTime}</span>
                  </article>
                ))}
              </div>
            </div>
          </section>
        )}
      </article>
    </div>
  );
};

Object.assign(window, { BlogPage, BlogPostPage, BLOG_POSTS });
