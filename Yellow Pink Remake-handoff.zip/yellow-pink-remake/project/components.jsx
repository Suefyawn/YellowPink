/* Yellow Pink — Shared Components */

/* ── Brand Logo Mark (geometric motif from logo) ── */
const LogoMark = ({ size = 20, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
    <circle cx="8" cy="12" r="6" fill="var(--brand-yellow)" opacity="0.9"/>
    <circle cx="16" cy="12" r="6" fill="var(--brand-pink)" opacity="0.9"/>
  </svg>
);

const LogoWordmark = ({ color = 'var(--ink-900)' }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
    <LogoMark size={28} />
    <span style={{
      fontFamily: 'var(--font-display)', fontWeight: 500, fontSize: '1.25rem',
      color, letterSpacing: '-0.02em'
    }}>Yellow Pink</span>
  </div>
);

/* ── Section Divider (logo mark between sections) ── */
const SectionDivider = () => (
  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 16, padding: '0' }}>
    <div style={{ flex: 1, maxWidth: 120, height: 1, background: 'var(--line)' }}></div>
    <LogoMark size={14} />
    <div style={{ flex: 1, maxWidth: 120, height: 1, background: 'var(--line)' }}></div>
  </div>
);

/* ── Overline Label ── */
const Overline = ({ children, style = {} }) => (
  <span className="overline" style={style}>{children}</span>
);

/* ── Product Tile ── */
const ProductTile = ({ brand, name, variant, price, originalPrice, onAddToCart, onClick }) => {
  const [hovered, setHovered] = React.useState(false);
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        cursor: 'pointer',
        transform: hovered ? 'translateY(-2px)' : 'translateY(0)',
        transition: 'transform 180ms ease-out',
      }}
    >
      <div className="img-placeholder" style={{
        width: '100%', aspectRatio: '1', borderRadius: 'var(--radius-card)',
        marginBottom: 12, position: 'relative'
      }}>
        <span style={{ padding: 16 }}>product photo</span>
        {originalPrice && (
          <span style={{
            position: 'absolute', top: 8, left: 8,
            background: 'var(--brand-yellow)', color: 'var(--ink-900)',
            padding: '2px 8px', borderRadius: 'var(--radius-pill)',
            fontSize: '0.6875rem', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase'
          }}>Sale</span>
        )}
      </div>
      <Overline style={{ color: 'var(--ink-500)', marginBottom: 2, display: 'block' }}>{brand}</Overline>
      <div className="h3" style={{ marginBottom: 2, position: 'relative', display: 'inline-block' }}>
        {name}
        <div style={{
          position: 'absolute', bottom: -1, left: 0, right: 0, height: 2,
          background: 'var(--brand-yellow)',
          transform: hovered ? 'scaleX(1)' : 'scaleX(0)',
          transformOrigin: 'left', transition: 'transform 180ms ease-out'
        }}></div>
      </div>
      {variant && <div className="small-text" style={{ marginBottom: 4 }}>{variant}</div>}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 4 }}>
        <span className="tabular-nums" style={{ fontWeight: 600, fontSize: '0.9375rem' }}>PKR {price.toLocaleString()}</span>
        {originalPrice && (
          <span className="tabular-nums" style={{
            textDecoration: 'line-through', color: 'var(--brand-pink)',
            fontSize: '0.8125rem'
          }}>PKR {originalPrice.toLocaleString()}</span>
        )}
      </div>
    </div>
  );
};

/* ── Announcement Bar ── */
const AnnouncementBar = () => (
  <div style={{
    background: 'var(--ink-900)', color: 'var(--paper)',
    padding: '10px 0', textAlign: 'center',
    fontFamily: 'var(--font-ui)', fontSize: '0.75rem', fontWeight: 500,
    letterSpacing: '0.06em', textTransform: 'uppercase',
  }}>
    <span>Free delivery on orders over </span>
    <span style={{
      borderBottom: '2px solid var(--brand-yellow)', paddingBottom: 1
    }}>PKR 2,500</span>
    <span> — COD Nationwide</span>
  </div>
);

/* ── Sticky Header ── */
const Header = ({ cartCount = 0, onCartClick, onNavigate, onSearchClick }) => {
  const [scrolled, setScrolled] = React.useState(false);
  const [mobileMenu, setMobileMenu] = React.useState(false);
  React.useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', fn, { passive: true });
    return () => window.removeEventListener('scroll', fn);
  }, []);
  const navItems = ['Makeup', 'Skincare', 'Wellness', 'Shop', 'Blog'];
  return (
    <header style={{
      position: 'sticky', top: 0, zIndex: 100,
      background: 'var(--paper)',
      borderBottom: '1px solid var(--line)',
      transition: 'padding 200ms ease-out',
      padding: scrolled ? '8px 0' : '14px 0',
    }}>
      <div className="container" style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div onClick={() => onNavigate && onNavigate('home')} style={{ cursor: 'pointer' }}>
          <LogoWordmark />
        </div>
        <nav style={{
          display: 'flex', gap: 32, alignItems: 'center',
        }} className="desktop-nav">
          {navItems.map(item => (
            <button key={item} onClick={() => onNavigate && onNavigate(item.toLowerCase())}
              style={{
                background: 'none', border: 'none', cursor: 'pointer',
                fontFamily: 'var(--font-ui)', fontSize: '0.8125rem', fontWeight: 500,
                color: 'var(--ink-700)', letterSpacing: '0.02em',
                padding: '4px 0', position: 'relative',
              }}
              onMouseEnter={e => e.target.style.color = 'var(--ink-900)'}
              onMouseLeave={e => e.target.style.color = 'var(--ink-700)'}
            >{item}</button>
          ))}
        </nav>
        <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
          {/* Search */}
          <button onClick={() => onSearchClick && onSearchClick()} style={{ background:'none', border:'none', cursor:'pointer', color:'var(--ink-700)', display:'flex' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          </button>
          {/* Account */}
          <button style={{ background:'none', border:'none', cursor:'pointer', color:'var(--ink-700)', display:'flex' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          </button>
          {/* Cart */}
          <button onClick={onCartClick} style={{
            background:'none', border:'none', cursor:'pointer', color:'var(--ink-900)',
            display:'flex', alignItems:'center', gap: 4, position: 'relative'
          }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>
            {cartCount > 0 && (
              <span style={{
                position: 'absolute', top: -6, right: -8,
                background: 'var(--brand-pink)', color: '#fff',
                width: 16, height: 16, borderRadius: '50%',
                fontSize: '0.625rem', fontWeight: 700,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>{cartCount}</span>
            )}
          </button>
          {/* Mobile menu toggle */}
          <button className="mobile-menu-btn" onClick={() => setMobileMenu(!mobileMenu)} style={{
            background:'none', border:'none', cursor:'pointer', color:'var(--ink-900)', display:'none'
          }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              {mobileMenu ? <><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></> :
                <><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></>}
            </svg>
          </button>
        </div>
      </div>
      {mobileMenu && (
        <div style={{ padding: '16px var(--side)', borderTop: '1px solid var(--line)', display: 'flex', flexDirection: 'column', gap: 16 }}>
          {navItems.map(item => (
            <button key={item} onClick={() => { onNavigate && onNavigate(item.toLowerCase()); setMobileMenu(false); }}
              style={{ background:'none', border:'none', textAlign:'left', cursor:'pointer', fontFamily:'var(--font-ui)', fontSize:'0.9375rem', fontWeight:500, color:'var(--ink-900)' }}
            >{item}</button>
          ))}
        </div>
      )}
    </header>
  );
};

/* ── Footer ── */
const Footer = () => (
  <footer style={{ background: 'var(--ink-900)', color: 'var(--paper)', padding: '64px 0 32px', position: 'relative', overflow: 'hidden' }}>
    {/* Watermark */}
    <div style={{ position: 'absolute', bottom: 20, right: 30, opacity: 0.04 }}>
      <LogoMark size={200} />
    </div>
    <div className="container">
      {/* Marquee */}
      <div style={{
        borderBottom: '1px solid rgba(250,246,238,0.1)', paddingBottom: 32, marginBottom: 40,
        overflow: 'hidden', whiteSpace: 'nowrap',
      }}>
        <div style={{
          display: 'inline-block',
          animation: 'marquee 30s linear infinite',
          fontFamily: 'var(--font-display)', fontSize: '1.5rem', fontStyle: 'italic',
          color: 'rgba(250,246,238,0.2)',
        }}>
          {Array(6).fill('Yellow Pink Store Pakistan · ').join('')}
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 40 }}>
        <div>
          <div style={{ marginBottom: 24 }}><LogoWordmark color="var(--paper)" /></div>
          <p className="small-text" style={{ color: 'rgba(250,246,238,0.5)', maxWidth: 260 }}>
            Quality ingredients. Real results. Imported beauty & wellness delivered across Pakistan.
          </p>
        </div>
        <div>
          <Overline style={{ color: 'rgba(250,246,238,0.4)', display: 'block', marginBottom: 16 }}>Shop</Overline>
          {['Makeup', 'Skincare', 'Wellness', 'All Products'].map(l => (
            <div key={l} style={{ marginBottom: 10 }}>
              <a href="#" style={{ color: 'rgba(250,246,238,0.7)', textDecoration: 'none', fontSize: '0.875rem', transition: 'color 150ms' }}
                onMouseEnter={e => e.target.style.color = 'var(--paper)'}
                onMouseLeave={e => e.target.style.color = 'rgba(250,246,238,0.7)'}
              >{l}</a>
            </div>
          ))}
        </div>
        <div>
          <Overline style={{ color: 'rgba(250,246,238,0.4)', display: 'block', marginBottom: 16 }}>Company</Overline>
          {['About Us', 'Blog', 'Contact', 'Shipping Policy'].map(l => (
            <div key={l} style={{ marginBottom: 10 }}>
              <a href="#" style={{ color: 'rgba(250,246,238,0.7)', textDecoration: 'none', fontSize: '0.875rem' }}
                onMouseEnter={e => e.target.style.color = 'var(--paper)'}
                onMouseLeave={e => e.target.style.color = 'rgba(250,246,238,0.7)'}
              >{l}</a>
            </div>
          ))}
        </div>
        <div>
          <Overline style={{ color: 'rgba(250,246,238,0.4)', display: 'block', marginBottom: 16 }}>Newsletter</Overline>
          <p className="small-text" style={{ color: 'rgba(250,246,238,0.5)', marginBottom: 12 }}>Sign up for health tips & exclusive offers.</p>
          <div style={{ display: 'flex', gap: 0 }}>
            <input type="email" placeholder="your@email.com" style={{
              flex: 1, padding: '10px 12px', background: 'rgba(250,246,238,0.08)', border: '1px solid rgba(250,246,238,0.15)',
              borderRight: 'none', borderRadius: '3px 0 0 3px', color: 'var(--paper)', fontSize: '0.8125rem', outline: 'none',
              fontFamily: 'var(--font-ui)'
            }} />
            <button style={{
              padding: '10px 16px', background: 'var(--brand-pink)', border: 'none',
              borderRadius: '0 3px 3px 0', color: '#fff', fontSize: '0.75rem', fontWeight: 600,
              letterSpacing: '0.06em', cursor: 'pointer', fontFamily: 'var(--font-ui)', textTransform: 'uppercase'
            }}>Join</button>
          </div>
        </div>
      </div>
      <div style={{
        marginTop: 48, paddingTop: 24, borderTop: '1px solid rgba(250,246,238,0.08)',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 16
      }}>
        <span className="small-text" style={{ color: 'rgba(250,246,238,0.3)' }}>© 2026 Yellow Pink. All rights reserved.</span>
        <div style={{ display: 'flex', gap: 16 }}>
          {['Instagram', 'TikTok', 'Facebook'].map(s => (
            <a key={s} href="#" style={{ color: 'rgba(250,246,238,0.4)', textDecoration: 'none', fontSize: '0.75rem' }}
              onMouseEnter={e => e.target.style.color = 'var(--paper)'}
              onMouseLeave={e => e.target.style.color = 'rgba(250,246,238,0.4)'}
            >{s}</a>
          ))}
        </div>
      </div>
    </div>
  </footer>
);

/* ── Mini Cart Drawer ── */
const MiniCart = ({ open, onClose, items = [], onRemove, onUpdateQty, onViewCart }) => {
  const FREE_SHIPPING = 2500;
  const total = items.reduce((s, i) => s + i.price * i.qty, 0);
  const progress = Math.min(total / FREE_SHIPPING, 1);

  return (
    <>
      {/* Backdrop */}
      <div onClick={onClose} style={{
        position: 'fixed', inset: 0, background: 'rgba(10,10,10,0.4)',
        opacity: open ? 1 : 0, pointerEvents: open ? 'auto' : 'none',
        transition: 'opacity 250ms ease-out', zIndex: 200,
      }}></div>
      {/* Drawer */}
      <div style={{
        position: 'fixed', top: 0, right: 0, bottom: 0, width: 400, maxWidth: '90vw',
        background: 'var(--paper)', boxShadow: 'var(--shadow-1)',
        transform: open ? 'translateX(0)' : 'translateX(100%)',
        transition: 'transform 300ms ease-out', zIndex: 201,
        display: 'flex', flexDirection: 'column',
      }}>
        {/* Header */}
        <div style={{ padding: '20px 24px', borderBottom: '1px solid var(--line)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span className="h3">Your Cart</span>
          <button onClick={onClose} style={{ background:'none', border:'none', cursor:'pointer', color:'var(--ink-900)', fontSize:'1.25rem' }}>×</button>
        </div>
        {/* Shipping progress */}
        <div style={{ padding: '16px 24px', borderBottom: '1px solid var(--line)' }}>
          <div className="small-text" style={{ marginBottom: 8, color: 'var(--ink-700)' }}>
            {progress >= 1
              ? <span style={{ color: 'var(--success)', fontWeight: 600 }}>You qualify for free shipping!</span>
              : <>PKR {(FREE_SHIPPING - total).toLocaleString()} away from <span style={{ color: 'var(--brand-pink)', fontWeight: 600 }}>FREE</span> shipping</>
            }
          </div>
          <div style={{ height: 4, background: 'var(--paper2)', borderRadius: 'var(--radius-pill)', overflow: 'hidden' }}>
            <div style={{
              height: '100%', width: `${progress * 100}%`,
              background: 'linear-gradient(90deg, var(--brand-yellow), var(--brand-pink))',
              borderRadius: 'var(--radius-pill)',
              transition: 'width 400ms ease-out',
            }}></div>
          </div>
        </div>
        {/* Items */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '16px 24px' }}>
          {items.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '40px 0', color: 'var(--ink-500)' }}>
              <p className="body-text">Your cart is empty</p>
            </div>
          ) : items.map((item, i) => (
            <div key={i} style={{ display: 'flex', gap: 12, padding: '12px 0', borderBottom: '1px solid var(--line)' }}>
              <div className="img-placeholder" style={{ width: 64, height: 64, borderRadius: 'var(--radius-card)', flexShrink: 0, fontSize: '0.5rem' }}>photo</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <Overline style={{ color: 'var(--ink-500)', fontSize: '0.5625rem', display: 'block' }}>{item.brand}</Overline>
                <div style={{ fontSize: '0.875rem', fontWeight: 600, marginBottom: 2 }}>{item.name}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 4 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 0, border: '1px solid var(--line)', borderRadius: 'var(--radius-card)' }}>
                    <button onClick={() => onUpdateQty(i, -1)} style={{ width: 28, height: 28, background: 'none', border: 'none', cursor: 'pointer', fontSize: '0.875rem' }}>−</button>
                    <span style={{ width: 24, textAlign: 'center', fontSize: '0.8125rem', fontWeight: 500 }}>{item.qty}</span>
                    <button onClick={() => onUpdateQty(i, 1)} style={{ width: 28, height: 28, background: 'none', border: 'none', cursor: 'pointer', fontSize: '0.875rem' }}>+</button>
                  </div>
                  <span className="tabular-nums" style={{ fontSize: '0.875rem', fontWeight: 600 }}>PKR {(item.price * item.qty).toLocaleString()}</span>
                </div>
              </div>
              <button onClick={() => onRemove(i)} style={{ background:'none', border:'none', cursor:'pointer', color:'var(--ink-500)', fontSize:'1rem', alignSelf:'flex-start', marginTop: 4 }}>×</button>
            </div>
          ))}
          {/* Free sample upsell */}
          {items.length > 0 && (
            <div style={{ marginTop: 16, padding: 12, background: 'var(--paper2)', borderRadius: 'var(--radius-card)', border: '1px solid var(--line)' }}>
              <Overline style={{ color: 'var(--brand-pink)', display: 'block', marginBottom: 4, fontSize: '0.625rem' }}>Add a Free Sample</Overline>
              <div className="small-text">Get a complimentary skincare sample with your order.</div>
            </div>
          )}
        </div>
        {/* Checkout */}
        {items.length > 0 && (
          <div style={{ padding: '20px 24px', borderTop: '1px solid var(--line)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
              <span className="h3">Total</span>
              <span className="h3 tabular-nums">PKR {total.toLocaleString()}</span>
            </div>
            <button className="btn-primary" style={{ width: '100%' }}>Checkout</button>
            <button onClick={() => { onClose(); onViewCart && onViewCart(); }} style={{
              width: '100%', marginTop: 8, padding: '10px 0', background: 'none', border: '1px solid var(--line)',
              borderRadius: 'var(--radius-card)', cursor: 'pointer',
              fontFamily: 'var(--font-ui)', fontSize: '0.8125rem', fontWeight: 600,
              color: 'var(--ink-900)', letterSpacing: '0.04em',
            }}>View Cart</button>
          </div>
        )}
      </div>
    </>
  );
};

/* Export to window */
Object.assign(window, {
  LogoMark, LogoWordmark, SectionDivider, Overline, ProductTile,
  AnnouncementBar, Header, Footer, MiniCart
});
