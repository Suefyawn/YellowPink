/* Yellow Pink — Homepage Sections v2 */

/* ── Real product catalog ── */
const ALL_PRODUCTS = [
  { brand: 'Tarte', name: 'Shape Tape Concealer', variant: 'Light-Medium Honey', price: 6500, originalPrice: 7800, category: 'Concealers' },
  { brand: 'Rhode', name: 'Peptide Lip Tints', variant: 'Raspberry Jelly', price: 4200, category: 'Lip Tints' },
  { brand: 'Rhode', name: 'Peptide Lip Tints', variant: 'Espresso', price: 4200, category: 'Lip Tints' },
  { brand: 'Rhode', name: 'Peptide Lip Tints', variant: 'Ribbon', price: 4200, category: 'Lip Tints' },
  { brand: 'NARS', name: 'Light Reflecting Foundation', variant: 'Mont Blanc', price: 8900, category: 'Foundations' },
  { brand: 'NARS', name: 'Light Reflecting Foundation', variant: 'Gobi', price: 8900, category: 'Foundations' },
  { brand: 'CeraVe', name: 'Acne Control Cleanser', variant: '237ml', price: 3200, originalPrice: 3800, category: 'Skincare' },
  { brand: 'SHEGLAM', name: 'Color Bloom Liquid Blush', variant: 'Risky Business', price: 1200, category: 'Blush' },
  { brand: 'SHEGLAM', name: 'Color Bloom Liquid Blush', variant: 'Float On', price: 1200, category: 'Blush' },
  { brand: 'Pixi', name: 'On-the-Glow Blush Stick', variant: 'Fleur', price: 3400, category: 'Blush' },
  { brand: 'Iconic London', name: 'Liquid Highlighter', variant: 'Original', price: 4800, category: 'Highlighters' },
  { brand: 'Yellow Pink', name: 'Anti-Melasma Cream', variant: 'Glutathione + Kojic Acid', price: 2800, originalPrice: 3500, category: 'Skincare' },
  { brand: 'Yellow Pink', name: 'Tinted Sunscreen SPF 46', variant: 'Universal Shade', price: 2400, category: 'Sunscreen' },
  { brand: 'CeraVe', name: 'Moisturizing Cream', variant: '340g', price: 3900, category: 'Skincare' },
  { brand: 'Tarte', name: 'Maracuja Juicy Lip Balm', variant: 'Rose', price: 3600, category: 'Lip Tints' },
  { brand: 'Pixi', name: 'Glow Tonic', variant: '100ml', price: 3100, category: 'Skincare' },
  { brand: 'NutraVit', name: 'Women\'s Fertility Complex', variant: '60 Capsules', price: 3800, category: 'Wellness' },
  { brand: 'NutraVit', name: 'Men\'s Vitality Formula', variant: '90 Capsules', price: 4200, category: 'Wellness' },
  { brand: 'NutraVit', name: 'Immune Defense + Zinc', variant: '30 Tablets', price: 1800, category: 'Wellness' },
  { brand: 'NutraVit', name: 'Bone Health Calcium D3', variant: '60 Tablets', price: 2200, category: 'Wellness' },
  { brand: 'NutraVit', name: 'Digestive Enzymes Pro', variant: '45 Capsules', price: 2600, category: 'Wellness' },
  { brand: 'NutraVit', name: 'Hair Skin Nails Biotin', variant: '5000mcg · 60 Gummies', price: 2900, category: 'Wellness' },
];
window.__ALL_PRODUCTS = ALL_PRODUCTS;

/* ── Hero ── */
const HeroSection = ({ onNavigate }) => (
  <section style={{ padding: 0, borderBottom: '1px solid var(--line)' }}>
    <div className="container hero-grid" style={{
      display: 'grid', gridTemplateColumns: '1.1fr 0.9fr', minHeight: 520, alignItems: 'center',
    }}>
      <div style={{ paddingRight: 48, paddingTop: 48, paddingBottom: 48 }}>
        <Overline style={{ display: 'block', marginBottom: 16, color: 'var(--ink-500)' }}>Beauty & Wellness · Inside Out</Overline>
        <h1 className="display-xl" style={{ marginBottom: 20 }}>
          Beautiful skin.<br /><em style={{ fontStyle: 'italic' }}>Vital health.</em>
        </h1>
        <p className="body-text" style={{ color: 'var(--ink-700)', maxWidth: 400, marginBottom: 28 }}>
          International skincare, makeup, and clinical-grade nutraceuticals — because real beauty is health from the inside out. Now in Pakistan with COD.
        </p>
        <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
          <button className="btn-primary" onClick={() => onNavigate && onNavigate('shop')}>Shop Beauty</button>
          <button className="btn-secondary" onClick={() => onNavigate && onNavigate('shop')}>Explore Wellness</button>
        </div>
        {/* Micro trust line */}
        <div style={{ marginTop: 24, display: 'flex', gap: 20, alignItems: 'center' }}>
          {['Tarte', 'NARS', 'Rhode', 'CeraVe'].map(b => (
            <span key={b} style={{ fontSize: '0.6875rem', fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--ink-500)' }}>{b}</span>
          ))}
        </div>
      </div>
      <div style={{ position: 'relative', alignSelf: 'stretch' }}>
        <div className="img-placeholder" style={{
          position: 'absolute', inset: 0, borderRadius: 0,
        }}>
          <span>hero: confident face +<br/>supplement bottle<br/>beauty meets vitality</span>
        </div>
        <div style={{
          position: 'absolute', bottom: 0, left: 0,
          width: 6, height: 80, background: 'var(--brand-yellow)',
        }}></div>
      </div>
    </div>
  </section>
);

/* ── Featured Products ── */
const FeaturedProducts = ({ onAddToCart, onProductClick }) => {
  const featured = ALL_PRODUCTS.slice(0, 4);
  return (
    <section style={{ padding: 'var(--section-gap) 0' }}>
      <div className="container">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 32 }}>
          <Overline>This Week</Overline>
          <button className="btn-secondary">View All</button>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 'var(--gutter)' }} className="product-grid">
          {featured.map((p, i) => (
            <ProductTile key={i} {...p}
              onAddToCart={() => onAddToCart(p)}
              onClick={() => onProductClick && onProductClick(p)}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

/* ── New Arrivals row ── */
const NewArrivals = ({ onAddToCart, onProductClick }) => {
  const items = ALL_PRODUCTS.slice(7, 11);
  return (
    <section style={{ paddingBottom: 'var(--section-gap)' }}>
      <div className="container">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 32 }}>
          <Overline>New Arrivals</Overline>
          <button className="btn-secondary">View All</button>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 'var(--gutter)' }} className="product-grid">
          {items.map((p, i) => (
            <ProductTile key={i} {...p}
              onAddToCart={() => onAddToCart(p)}
              onClick={() => onProductClick && onProductClick(p)}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

/* ── Editorial Duo ── */
const EditorialDuo = () => {
  const DuoCard = ({ title, subtitle, cta, imgLabel }) => {
    const [hovered, setHovered] = React.useState(false);
    return (
      <div onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}
        style={{ position: 'relative', overflow: 'hidden', cursor: 'pointer' }}>
        <div style={{ overflow: 'hidden', borderRadius: 'var(--radius-card)' }}>
          <div className="img-placeholder" style={{
            aspectRatio: '4/3',
            transform: hovered ? 'scale(1.02)' : 'scale(1)',
            transition: 'transform 400ms ease-out',
          }}>
            <span>{imgLabel}</span>
          </div>
        </div>
        <div style={{ marginTop: 16 }}>
          <Overline style={{ display: 'block', marginBottom: 6, color: 'var(--ink-500)' }}>{subtitle}</Overline>
          <h2 className="display-l" style={{ fontSize: '2rem', marginBottom: 12 }}>{title}</h2>
          <button className="btn-secondary">{cta}</button>
        </div>
      </div>
    );
  };
  return (
    <section style={{ paddingBottom: 'var(--section-gap)' }}>
      <div className="container">
        <SectionDivider />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--gutter)', marginTop: 'var(--section-gap)' }} className="duo-grid">
          <DuoCard title="Treat Melasma" subtitle="Real Solutions" cta="Explore Treatments" imgLabel="before/after melasma treatment" />
          <DuoCard title="Clear Skin" subtitle="Acne Care" cta="Shop Cleansers" imgLabel="clear skin close-up" />
        </div>
      </div>
    </section>
  );
};

/* ── Bestsellers band ── */
const BestsellersBand = ({ onProductClick }) => {
  const items = ALL_PRODUCTS.filter(p => ['Tarte', 'NARS', 'CeraVe', 'Rhode'].includes(p.brand)).slice(0, 3);
  return (
    <section style={{ background: 'var(--paper2)', padding: 'var(--section-gap) 0', borderTop: '1px solid var(--line)', borderBottom: '1px solid var(--line)' }}>
      <div className="container">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 48, alignItems: 'center' }} className="duo-grid">
          <div>
            <Overline style={{ display: 'block', marginBottom: 12, color: 'var(--ink-500)' }}>Bestsellers</Overline>
            <h2 className="display-l" style={{ fontSize: '2.25rem', marginBottom: 16 }}>
              What everyone's buying.
            </h2>
            <p className="body-text" style={{ color: 'var(--ink-700)', marginBottom: 20, maxWidth: 320 }}>
              The products our customers keep coming back to — tried, tested, loved.
            </p>
            <button className="btn-secondary">Shop Bestsellers</button>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 'var(--gutter)' }} className="product-grid-3">
            {items.map((p, i) => (
              <ProductTile key={i} {...p} onClick={() => onProductClick && onProductClick(p)} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

/* ── Category Tiles ── */
const CategoryTiles = () => {
  const cats = ['Foundations', 'Lip Tints', 'Concealers', 'Skincare', 'Sunscreen', 'Blush', 'Highlighters', 'Wellness'];
  return (
    <section style={{ padding: 'var(--section-gap) 0' }}>
      <div className="container">
        <Overline style={{ display: 'block', marginBottom: 32 }}>Categories</Overline>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 'var(--gutter)' }} className="cat-grid">
          {cats.map(cat => (
            <a key={cat} href="#" style={{ textDecoration: 'none', color: 'inherit' }}
              onMouseEnter={e => e.currentTarget.querySelector('.cat-img').style.transform = 'scale(1.04)'}
              onMouseLeave={e => e.currentTarget.querySelector('.cat-img').style.transform = 'scale(1)'}
            >
              <div style={{ overflow: 'hidden', borderRadius: 'var(--radius-card)' }}>
                <div className="img-placeholder cat-img" style={{
                  aspectRatio: '1', transition: 'transform 300ms ease-out',
                }}>
                  <span>{cat.toLowerCase()}</span>
                </div>
              </div>
              <Overline style={{ display: 'block', marginTop: 10, textAlign: 'center', color: 'var(--ink-700)' }}>{cat}</Overline>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};

/* ── Real Results ── */
const RealResults = () => {
  const people = [
    { name: 'Maria Javaid', condition: 'Melasma', quote: "I've tried hundreds of melasma treatments but nothing worked before this.", products: ['Anti-Melasma Cream'] },
    { name: 'Nida Saleem', condition: 'Acne', quote: "I've forgotten how it felt to have bumpy and uneven, acne-filled cheeks.", products: ['CeraVe Acne Cleanser'] },
    { name: 'Ayesha Khan', condition: 'Hyperpigmentation', quote: 'Visible results in just 3 weeks of consistent use.', products: ['Tinted Sunscreen SPF 46'] },
    { name: 'Fatima Ali', condition: 'Sun Damage', quote: 'My skin tone is finally even. I wish I found this sooner.', products: ['Anti-Melasma Cream', 'Tinted Sunscreen'] },
  ];
  const [selected, setSelected] = React.useState(null);
  return (
    <section style={{ paddingBottom: 'var(--section-gap)' }}>
      <div className="container">
        <SectionDivider />
        <div style={{ marginTop: 'var(--section-gap)' }}>
          <Overline style={{ display: 'block', marginBottom: 8 }}>Real Results</Overline>
          <h2 className="display-l" style={{ fontSize: '2.25rem', marginBottom: 32 }}>
            Real people. Life-changing results.
          </h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 'var(--gutter)' }} className="results-grid">
            {people.map((p, i) => (
              <div key={i} style={{ cursor: 'pointer' }} onClick={() => setSelected(selected === i ? null : i)}>
                <div className="img-placeholder" style={{
                  aspectRatio: '3/4', borderRadius: 'var(--radius-card)', marginBottom: 12,
                  border: selected === i ? '2px solid var(--brand-pink)' : '2px solid transparent',
                  transition: 'border-color 200ms ease-out',
                }}>
                  <span>portrait photo</span>
                </div>
                <div style={{ fontWeight: 600, fontSize: '0.9375rem' }}>{p.name}</div>
                <Overline style={{ color: 'var(--ink-500)', fontSize: '0.625rem', display: 'block', marginTop: 2 }}>{p.condition}</Overline>
                {selected === i && (
                  <div style={{ marginTop: 10 }}>
                    <p className="body-text" style={{ color: 'var(--ink-700)', fontStyle: 'italic', marginBottom: 8 }}>
                      "{p.quote}"
                    </p>
                    <Overline style={{ color: 'var(--ink-500)', fontSize: '0.5625rem', display: 'block' }}>Products Used</Overline>
                    {p.products.map((pr, j) => (
                      <span key={j} style={{
                        display: 'inline-block', marginTop: 4, marginRight: 6,
                        padding: '2px 8px', background: 'var(--paper2)',
                        borderRadius: 'var(--radius-pill)', fontSize: '0.75rem', fontWeight: 500,
                      }}>{pr}</span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

/* ── Press Strip ── */
const PressStrip = () => {
  const brands = ['ELLE', 'VOGUE', 'DAWN', 'GEO', 'THE NEWS', 'TRIBUNE'];
  return (
    <section style={{
      background: 'var(--ink-900)', padding: '24px 0',
    }}>
      <div className="container" style={{
        display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 48, flexWrap: 'wrap',
      }}>
        {brands.map(b => (
          <span key={b} style={{
            fontFamily: 'var(--font-ui)', fontSize: '0.75rem', fontWeight: 600,
            letterSpacing: '0.2em', textTransform: 'uppercase',
            color: 'rgba(250,246,238,0.35)',
          }}>{b}</span>
        ))}
      </div>
    </section>
  );
};

/* ── Trust bar ── */
const TrustBar = () => {
  const items = [
    { icon: '✦', label: '100% Authentic', sub: 'Imported directly' },
    { icon: '✦', label: 'Free Delivery', sub: 'Over PKR 2,500' },
    { icon: '✦', label: 'COD Nationwide', sub: 'Pay on delivery' },
    { icon: '✦', label: 'Easy Returns', sub: '7-day policy' },
  ];
  return (
    <section style={{ padding: '32px 0', borderTop: '1px solid var(--line)', borderBottom: '1px solid var(--line)' }}>
      <div className="container" style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 'var(--gutter)', textAlign: 'center' }} className="container trust-grid">
        {items.map((it, i) => (
          <div key={i}>
            <div style={{ fontSize: '0.625rem', color: 'var(--brand-yellow)', marginBottom: 4 }}>{it.icon}</div>
            <div style={{ fontSize: '0.8125rem', fontWeight: 600, marginBottom: 2 }}>{it.label}</div>
            <div className="small-text">{it.sub}</div>
          </div>
        ))}
      </div>
    </section>
  );
};

/* ── Wellness / Nutraceuticals Section ── */
const WellnessSection = ({ onProductClick }) => {
  const wellnessProducts = ALL_PRODUCTS.filter(p => p.category === 'Wellness').slice(0, 3);
  const pillars = [
    { label: "Women's Health", desc: 'Fertility, prenatal, hormonal balance', icon: '○' },
    { label: "Men's Vitality", desc: 'Performance, stamina, reproductive health', icon: '○' },
    { label: 'Immune Support', desc: 'Defense, zinc, daily wellness', icon: '○' },
    { label: 'Bone & Joint', desc: 'Calcium D3, mobility, strength', icon: '○' },
  ];

  return (
    <section style={{ padding: 'var(--section-gap) 0' }}>
      <div className="container">
        <SectionDivider />
        <div style={{ marginTop: 'var(--section-gap)' }}>
          {/* Header row */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 48, alignItems: 'start', marginBottom: 48 }} className="duo-grid">
            <div>
              <Overline style={{ display: 'block', marginBottom: 12, color: 'var(--ink-500)' }}>Beyond Beauty</Overline>
              <h2 className="display-l" style={{ fontSize: '2.5rem', marginBottom: 16 }}>
                Beauty starts<br /><em style={{ fontStyle: 'italic' }}>from within.</em>
              </h2>
              <p className="body-text" style={{ color: 'var(--ink-700)', maxWidth: 400 }}>
                Clinical-grade nutraceuticals for fertility, immunity, bone health, and daily vitality. 
                Because real beauty is health — inside out.
              </p>
            </div>
            {/* Wellness pillars grid */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              {pillars.map((p, i) => (
                <div key={i} style={{
                  padding: 16, background: 'var(--paper2)', borderRadius: 'var(--radius-card)',
                  border: '1px solid var(--line)', cursor: 'pointer',
                  transition: 'border-color 180ms ease-out',
                }}
                  onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--brand-yellow)'}
                  onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--line)'}
                >
                  <div style={{
                    width: 24, height: 4, background: 'var(--brand-yellow)',
                    borderRadius: 2, marginBottom: 10,
                  }}></div>
                  <div style={{ fontSize: '0.875rem', fontWeight: 600, marginBottom: 2 }}>{p.label}</div>
                  <div className="small-text" style={{ lineHeight: 1.4 }}>{p.desc}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Wellness product tiles */}
          <div style={{
            display: 'grid', gridTemplateColumns: '1fr repeat(3, 1fr)', gap: 'var(--gutter)',
            alignItems: 'center',
          }} className="wellness-grid">
            {/* Big editorial image */}
            <div className="img-placeholder" style={{
              aspectRatio: '3/4', borderRadius: 'var(--radius-card)',
              position: 'relative',
            }}>
              <span>wellness lifestyle<br/>supplements + person</span>
              <div style={{
                position: 'absolute', top: 20, left: 20,
                background: 'var(--brand-yellow)', padding: '6px 12px',
                borderRadius: 'var(--radius-pill)',
              }}>
                <span style={{ fontSize: '0.6875rem', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--ink-900)' }}>
                  New Category
                </span>
              </div>
            </div>
            {/* 3 product tiles */}
            {wellnessProducts.map((p, i) => (
              <ProductTile key={i} {...p} onClick={() => onProductClick && onProductClick(p)} />
            ))}
          </div>

          {/* CTA */}
          <div style={{ marginTop: 32, display: 'flex', justifyContent: 'center' }}>
            <button className="btn-secondary">Explore Wellness</button>
          </div>
        </div>
      </div>
    </section>
  );
};

Object.assign(window, {
  HeroSection, FeaturedProducts, NewArrivals, EditorialDuo, BestsellersBand,
  CategoryTiles, RealResults, PressStrip, TrustBar, WellnessSection, ALL_PRODUCTS
});
