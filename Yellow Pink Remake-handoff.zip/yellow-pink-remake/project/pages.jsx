/* Yellow Pink — Cart, Checkout, Thank You, 404 Pages */

/* ── Cart Page ── */
const CartPage = ({ items, onRemove, onUpdateQty, onNavigate, onCheckout }) => {
  const FREE_SHIPPING = 2500;
  const total = items.reduce((s, i) => s + i.price * i.qty, 0);
  const progress = Math.min(total / FREE_SHIPPING, 1);
  const shipping = total >= FREE_SHIPPING ? 0 : 200;

  if (items.length === 0) {
    return (
      <section style={{ padding: 'var(--section-gap) 0', textAlign: 'center' }}>
        <div className="container" style={{ maxWidth: 560 }}>
          <LogoMark size={40} />
          <h1 className="h1" style={{ marginTop: 20, marginBottom: 12 }}>Your cart is empty</h1>
          <p className="body-text" style={{ color: 'var(--ink-700)', marginBottom: 28 }}>
            Looks like you haven't added anything yet. Explore our collection and find something you'll love.
          </p>
          <button className="btn-primary" onClick={() => onNavigate('shop')}>Continue Shopping</button>
        </div>
      </section>
    );
  }

  return (
    <div>
      <section style={{ padding: '48px 0 0' }}>
        <div className="container">
          <Overline style={{ display: 'block', marginBottom: 8, color: 'var(--ink-500)' }}>Shopping Cart</Overline>
          <h1 className="display-l" style={{ fontSize: '2rem', marginBottom: 32 }}>
            Your Cart ({items.reduce((s, i) => s + i.qty, 0)})
          </h1>
        </div>
      </section>

      <section style={{ padding: '0 0 var(--section-gap)' }}>
        <div className="container">
          {/* Shipping progress */}
          <div style={{ padding: '16px 0 32px', borderBottom: '1px solid var(--line)' }}>
            <div className="small-text" style={{ marginBottom: 8, color: 'var(--ink-700)' }}>
              {progress >= 1
                ? <span style={{ color: 'var(--success)', fontWeight: 600 }}>You qualify for free shipping!</span>
                : <>PKR {(FREE_SHIPPING - total).toLocaleString()} away from <span style={{ color: 'var(--brand-pink)', fontWeight: 600 }}>FREE</span> shipping</>
              }
            </div>
            <div style={{ height: 4, background: 'var(--paper2)', borderRadius: 'var(--radius-pill)', overflow: 'hidden', maxWidth: 400 }}>
              <div style={{
                height: '100%', width: `${progress * 100}%`,
                background: 'linear-gradient(90deg, var(--brand-yellow), var(--brand-pink))',
                borderRadius: 'var(--radius-pill)', transition: 'width 400ms ease-out',
              }}></div>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 48, marginTop: 32 }} className="duo-grid">
            {/* Line items */}
            <div>
              {/* Header */}
              <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 32px', gap: 16, paddingBottom: 12, borderBottom: '1px solid var(--line)' }}>
                <Overline style={{ color: 'var(--ink-500)' }}>Product</Overline>
                <Overline style={{ color: 'var(--ink-500)', textAlign: 'center' }}>Quantity</Overline>
                <Overline style={{ color: 'var(--ink-500)', textAlign: 'right' }}>Total</Overline>
                <span></span>
              </div>
              {items.map((item, i) => (
                <div key={i} style={{
                  display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 32px', gap: 16,
                  alignItems: 'center', padding: '20px 0', borderBottom: '1px solid var(--line)',
                }}>
                  <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
                    <div className="img-placeholder" style={{
                      width: 72, height: 72, borderRadius: 'var(--radius-card)', flexShrink: 0, fontSize: '0.5rem'
                    }}>photo</div>
                    <div>
                      <Overline style={{ color: 'var(--ink-500)', fontSize: '0.5625rem', display: 'block' }}>{item.brand}</Overline>
                      <div style={{ fontSize: '0.9375rem', fontWeight: 600 }}>{item.name}</div>
                      {item.variant && <div className="small-text">{item.variant}</div>}
                      <div className="tabular-nums small-text" style={{ marginTop: 2 }}>PKR {item.price.toLocaleString()}</div>
                    </div>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'center' }}>
                    <div style={{ display: 'flex', alignItems: 'center', border: '1px solid var(--line)', borderRadius: 'var(--radius-card)' }}>
                      <button onClick={() => onUpdateQty(i, -1)} style={{ width: 32, height: 32, background: 'none', border: 'none', cursor: 'pointer', fontSize: '0.875rem' }}>−</button>
                      <span style={{ width: 28, textAlign: 'center', fontSize: '0.8125rem', fontWeight: 500, fontVariantNumeric: 'tabular-nums' }}>{item.qty}</span>
                      <button onClick={() => onUpdateQty(i, 1)} style={{ width: 32, height: 32, background: 'none', border: 'none', cursor: 'pointer', fontSize: '0.875rem' }}>+</button>
                    </div>
                  </div>
                  <div className="tabular-nums" style={{ textAlign: 'right', fontWeight: 600, fontSize: '0.9375rem' }}>
                    PKR {(item.price * item.qty).toLocaleString()}
                  </div>
                  <button onClick={() => onRemove(i)} style={{
                    background: 'none', border: 'none', cursor: 'pointer', color: 'var(--ink-500)', fontSize: '1rem',
                  }}>×</button>
                </div>
              ))}
              <div style={{ marginTop: 20 }}>
                <button className="btn-secondary" onClick={() => onNavigate('shop')}>Continue Shopping</button>
              </div>
            </div>

            {/* Order summary */}
            <div style={{
              background: 'var(--paper2)', borderRadius: 'var(--radius-card)',
              padding: 28, border: '1px solid var(--line)', alignSelf: 'start',
              position: 'sticky', top: 100,
            }}>
              <Overline style={{ display: 'block', marginBottom: 20, color: 'var(--ink-500)' }}>Order Summary</Overline>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
                <span className="body-text">Subtotal</span>
                <span className="body-text tabular-nums" style={{ fontWeight: 500 }}>PKR {total.toLocaleString()}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
                <span className="body-text">Shipping</span>
                <span className="body-text tabular-nums" style={{ fontWeight: 500, color: shipping === 0 ? 'var(--success)' : 'inherit' }}>
                  {shipping === 0 ? 'FREE' : `PKR ${shipping}`}
                </span>
              </div>
              <hr className="hairline" style={{ margin: '16px 0' }} />
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 24 }}>
                <span className="h3">Total</span>
                <span className="h3 tabular-nums">PKR {(total + shipping).toLocaleString()}</span>
              </div>
              <button className="btn-primary" style={{ width: '100%' }} onClick={onCheckout}>
                Proceed to Checkout
              </button>
              <p className="small-text" style={{ textAlign: 'center', marginTop: 12, color: 'var(--ink-500)' }}>
                COD available nationwide
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

/* ── Checkout Page ── */
const CheckoutPage = ({ items, onNavigate, onPlaceOrder }) => {
  const FREE_SHIPPING = 2500;
  const total = items.reduce((s, i) => s + i.price * i.qty, 0);
  const shipping = total >= FREE_SHIPPING ? 0 : 200;
  const [payMethod, setPayMethod] = React.useState('cod');
  const [formData, setFormData] = React.useState({
    email: '', firstName: '', lastName: '', phone: '',
    address: '', city: '', province: '', zip: '',
  });
  const [errors, setErrors] = React.useState({});

  const update = (key, val) => {
    setFormData(p => ({ ...p, [key]: val }));
    if (errors[key]) setErrors(p => { const n = {...p}; delete n[key]; return n; });
  };

  const validate = () => {
    const e = {};
    if (!formData.firstName.trim()) e.firstName = 'Required';
    if (!formData.lastName.trim()) e.lastName = 'Required';
    if (!formData.phone.trim()) e.phone = 'Required';
    if (!formData.address.trim()) e.address = 'Required';
    if (!formData.city.trim()) e.city = 'Required';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (validate()) onPlaceOrder && onPlaceOrder();
  };

  const inputStyle = (key) => ({
    width: '100%', padding: '10px 12px',
    border: `1px solid ${errors[key] ? 'var(--error)' : 'var(--line)'}`,
    borderRadius: 'var(--radius-card)', fontFamily: 'var(--font-ui)',
    fontSize: '0.875rem', color: 'var(--ink-900)', background: 'var(--paper)',
    outline: 'none', transition: 'border-color 150ms',
  });

  const labelStyle = { display: 'block', fontSize: '0.8125rem', fontWeight: 500, marginBottom: 6 };

  return (
    <div>
      <section style={{ padding: '48px 0 0', borderBottom: '1px solid var(--line)' }}>
        <div className="container">
          <Overline style={{ display: 'block', marginBottom: 8, color: 'var(--ink-500)' }}>Checkout</Overline>
          <h1 className="display-l" style={{ fontSize: '2rem', marginBottom: 32 }}>Complete Your Order</h1>
        </div>
      </section>

      <section style={{ padding: '40px 0 var(--section-gap)' }}>
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 48 }} className="duo-grid">
            {/* Form */}
            <div>
              {/* Contact */}
              <Overline style={{ display: 'block', marginBottom: 16 }}>Contact</Overline>
              <div style={{ marginBottom: 24 }}>
                <label style={labelStyle}>Email (optional)</label>
                <input type="email" value={formData.email} onChange={e => update('email', e.target.value)}
                  placeholder="For order updates" style={inputStyle('email')} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 24 }}>
                <div>
                  <label style={labelStyle}>Phone *</label>
                  <input type="tel" value={formData.phone} onChange={e => update('phone', e.target.value)}
                    placeholder="+92 300 1234567" style={inputStyle('phone')} />
                  {errors.phone && <span style={{ fontSize: '0.75rem', color: 'var(--error)' }}>{errors.phone}</span>}
                </div>
                <div></div>
              </div>

              <hr className="hairline" style={{ margin: '32px 0' }} />

              {/* Shipping */}
              <Overline style={{ display: 'block', marginBottom: 16 }}>Shipping Address</Overline>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
                <div>
                  <label style={labelStyle}>First Name *</label>
                  <input value={formData.firstName} onChange={e => update('firstName', e.target.value)}
                    style={inputStyle('firstName')} />
                  {errors.firstName && <span style={{ fontSize: '0.75rem', color: 'var(--error)' }}>{errors.firstName}</span>}
                </div>
                <div>
                  <label style={labelStyle}>Last Name *</label>
                  <input value={formData.lastName} onChange={e => update('lastName', e.target.value)}
                    style={inputStyle('lastName')} />
                  {errors.lastName && <span style={{ fontSize: '0.75rem', color: 'var(--error)' }}>{errors.lastName}</span>}
                </div>
              </div>
              <div style={{ marginBottom: 16 }}>
                <label style={labelStyle}>Address *</label>
                <input value={formData.address} onChange={e => update('address', e.target.value)}
                  placeholder="House/flat, street, area" style={inputStyle('address')} />
                {errors.address && <span style={{ fontSize: '0.75rem', color: 'var(--error)' }}>{errors.address}</span>}
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16, marginBottom: 16 }}>
                <div>
                  <label style={labelStyle}>City *</label>
                  <input value={formData.city} onChange={e => update('city', e.target.value)}
                    style={inputStyle('city')} />
                  {errors.city && <span style={{ fontSize: '0.75rem', color: 'var(--error)' }}>{errors.city}</span>}
                </div>
                <div>
                  <label style={labelStyle}>Province</label>
                  <select value={formData.province} onChange={e => update('province', e.target.value)}
                    style={{ ...inputStyle('province'), cursor: 'pointer' }}>
                    <option value="">Select</option>
                    {['Punjab', 'Sindh', 'KPK', 'Balochistan', 'Islamabad', 'AJK', 'Gilgit-Baltistan'].map(p => (
                      <option key={p} value={p}>{p}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label style={labelStyle}>Postal Code</label>
                  <input value={formData.zip} onChange={e => update('zip', e.target.value)}
                    style={inputStyle('zip')} />
                </div>
              </div>

              <hr className="hairline" style={{ margin: '32px 0' }} />

              {/* Payment */}
              <Overline style={{ display: 'block', marginBottom: 16 }}>Payment Method</Overline>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
                {[
                  { key: 'cod', label: 'Cash on Delivery (COD)', desc: 'Pay when your order arrives' },
                  { key: 'card', label: 'Credit / Debit Card', desc: 'Visa, Mastercard, JazzCash' },
                  { key: 'bank', label: 'Bank Transfer', desc: 'Direct bank deposit' },
                ].map(pm => (
                  <label key={pm.key} onClick={() => setPayMethod(pm.key)} style={{
                    display: 'flex', alignItems: 'flex-start', gap: 12, padding: '16px',
                    border: '1px solid ' + (payMethod === pm.key ? 'var(--ink-900)' : 'var(--line)'),
                    borderRadius: 'var(--radius-card)', cursor: 'pointer',
                    marginBottom: -1, background: payMethod === pm.key ? 'var(--paper2)' : 'transparent',
                    transition: 'all 150ms',
                  }}>
                    <div style={{
                      width: 18, height: 18, borderRadius: '50%', flexShrink: 0, marginTop: 1,
                      border: payMethod === pm.key ? '5px solid var(--ink-900)' : '2px solid var(--line)',
                      transition: 'border 150ms',
                    }}></div>
                    <div>
                      <div style={{ fontSize: '0.875rem', fontWeight: 600 }}>{pm.label}</div>
                      <div className="small-text">{pm.desc}</div>
                    </div>
                  </label>
                ))}
              </div>

              {/* Mobile place order */}
              <div style={{ marginTop: 32 }} className="mobile-only-btn">
                <button className="btn-primary" style={{ width: '100%' }} onClick={handleSubmit}>
                  Place Order — PKR {(total + shipping).toLocaleString()}
                </button>
              </div>
            </div>

            {/* Order summary sidebar */}
            <div style={{
              background: 'var(--paper2)', borderRadius: 'var(--radius-card)',
              padding: 28, border: '1px solid var(--line)', alignSelf: 'start',
              position: 'sticky', top: 100,
            }}>
              <Overline style={{ display: 'block', marginBottom: 16, color: 'var(--ink-500)' }}>Your Order</Overline>
              {items.map((item, i) => (
                <div key={i} style={{ display: 'flex', gap: 12, marginBottom: 12 }}>
                  <div className="img-placeholder" style={{
                    width: 48, height: 48, borderRadius: 'var(--radius-card)', flexShrink: 0, fontSize: '0.45rem',
                    position: 'relative',
                  }}>
                    img
                    <span style={{
                      position: 'absolute', top: -6, right: -6,
                      background: 'var(--ink-900)', color: 'var(--paper)',
                      width: 18, height: 18, borderRadius: '50%',
                      fontSize: '0.625rem', fontWeight: 700,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}>{item.qty}</span>
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: '0.8125rem', fontWeight: 600 }}>{item.name}</div>
                    {item.variant && <div className="small-text" style={{ fontSize: '0.6875rem' }}>{item.variant}</div>}
                  </div>
                  <span className="tabular-nums" style={{ fontSize: '0.8125rem', fontWeight: 500, flexShrink: 0 }}>
                    PKR {(item.price * item.qty).toLocaleString()}
                  </span>
                </div>
              ))}
              <hr className="hairline" style={{ margin: '16px 0' }} />
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                <span className="small-text">Subtotal</span>
                <span className="small-text tabular-nums" style={{ fontWeight: 500 }}>PKR {total.toLocaleString()}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                <span className="small-text">Shipping</span>
                <span className="small-text tabular-nums" style={{ fontWeight: 500, color: shipping === 0 ? 'var(--success)' : 'inherit' }}>
                  {shipping === 0 ? 'FREE' : `PKR ${shipping}`}
                </span>
              </div>
              <hr className="hairline" style={{ margin: '16px 0' }} />
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 24 }}>
                <span className="h3">Total</span>
                <span className="h3 tabular-nums">PKR {(total + shipping).toLocaleString()}</span>
              </div>
              <button className="btn-primary" style={{ width: '100%' }} onClick={handleSubmit}>
                Place Order
              </button>
              <p className="small-text" style={{ textAlign: 'center', marginTop: 12, color: 'var(--ink-500)' }}>
                Secure checkout · COD available
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

/* ── Thank You Page ── */
const ThankYouPage = ({ onNavigate }) => {
  const orderNumber = React.useMemo(() => 'YP-' + Math.random().toString(36).substring(2, 8).toUpperCase(), []);
  return (
    <section style={{ padding: 'var(--section-gap) 0', textAlign: 'center' }}>
      <div className="container" style={{ maxWidth: 560 }}>
        <div style={{ marginBottom: 24 }}>
          <div style={{
            width: 64, height: 64, borderRadius: '50%', background: 'var(--success)',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            marginBottom: 20,
          }}>
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="20 6 9 17 4 12"/>
            </svg>
          </div>
        </div>
        <Overline style={{ display: 'block', marginBottom: 12, color: 'var(--ink-500)' }}>Order Confirmed</Overline>
        <h1 className="display-l" style={{ fontSize: '2.5rem', marginBottom: 12 }}>
          Thank you!
        </h1>
        <p className="body-text" style={{ color: 'var(--ink-700)', marginBottom: 8 }}>
          Your order <strong>{orderNumber}</strong> has been placed successfully.
        </p>
        <p className="body-text" style={{ color: 'var(--ink-700)', marginBottom: 32 }}>
          We'll send you a confirmation on WhatsApp with tracking details once your order ships. Delivery typically takes 2–4 business days.
        </p>

        <div style={{
          background: 'var(--paper2)', border: '1px solid var(--line)',
          borderRadius: 'var(--radius-card)', padding: 24, marginBottom: 32,
          textAlign: 'left',
        }}>
          <Overline style={{ display: 'block', marginBottom: 16, color: 'var(--ink-500)' }}>What Happens Next</Overline>
          {[
            { step: '1', label: 'Order Processing', desc: 'We\'re packing your items with care.' },
            { step: '2', label: 'Shipped', desc: 'You\'ll receive tracking via WhatsApp.' },
            { step: '3', label: 'Delivered', desc: 'Pay on delivery (COD) or already paid.' },
          ].map((s, i) => (
            <div key={i} style={{ display: 'flex', gap: 16, alignItems: 'flex-start', marginBottom: i < 2 ? 16 : 0 }}>
              <div style={{
                width: 28, height: 28, borderRadius: '50%', flexShrink: 0,
                background: 'var(--brand-yellow)', display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: '0.75rem', fontWeight: 700,
              }}>{s.step}</div>
              <div>
                <div style={{ fontSize: '0.875rem', fontWeight: 600, marginBottom: 2 }}>{s.label}</div>
                <div className="small-text">{s.desc}</div>
              </div>
            </div>
          ))}
        </div>

        <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
          <button className="btn-primary" onClick={() => onNavigate('shop')}>Continue Shopping</button>
          <button className="btn-secondary" onClick={() => onNavigate('home')}>Back to Home</button>
        </div>
      </div>
    </section>
  );
};

/* ── 404 Page ── */
const NotFoundPage = ({ onNavigate }) => (
  <section style={{ padding: 'var(--section-gap) 0', textAlign: 'center' }}>
    <div className="container" style={{ maxWidth: 560 }}>
      <div style={{ marginBottom: 24 }}>
        <LogoMark size={48} />
      </div>
      <h1 style={{
        fontFamily: 'var(--font-display)', fontSize: '6rem', fontWeight: 500,
        letterSpacing: '-0.03em', lineHeight: 1, marginBottom: 12,
        color: 'var(--ink-900)',
      }}>404</h1>
      <p className="h2" style={{ marginBottom: 12 }}>Page not found</p>
      <p className="body-text" style={{ color: 'var(--ink-700)', marginBottom: 32 }}>
        The page you're looking for doesn't exist or has been moved. Let's get you back on track.
      </p>
      <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
        <button className="btn-primary" onClick={() => onNavigate('home')}>Go Home</button>
        <button className="btn-secondary" onClick={() => onNavigate('shop')}>Browse Shop</button>
      </div>
    </div>
  </section>
);

Object.assign(window, { CartPage, CheckoutPage, ThankYouPage, NotFoundPage });
