/* Yellow Pink — Product Detail Page */

const PDPPage = ({ product, onAddToCart, onBack }) => {
  const [selectedImage, setSelectedImage] = React.useState(0);
  const [qty, setQty] = React.useState(1);
  const [expandedSection, setExpandedSection] = React.useState(null);
  const [addedFlash, setAddedFlash] = React.useState(false);
  const images = [0, 1, 2, 3];

  const handleAdd = () => {
    setAddedFlash(true);
    onAddToCart && onAddToCart({ ...product, qty });
    setTimeout(() => setAddedFlash(false), 400);
  };

  const expandables = [
    { key: 'use', title: 'How to Use', content: 'Apply a small amount to clean skin. Blend evenly with fingertips or a brush for desired coverage. For best results, use with a primer.' },
    { key: 'ingredients', title: 'Ingredients', content: 'Water, Cyclopentasiloxane, Titanium Dioxide, Glycerin, Dimethicone, Niacinamide, Tocopheryl Acetate, Hyaluronic Acid.' },
    { key: 'reviews', title: 'Reviews (24)', content: 'Customers love this product for its blendability and long wear. Average rating: 4.7/5.' },
    { key: 'shipping', title: 'Shipping & Returns', content: 'Free shipping on orders over PKR 2,500. COD available nationwide. 7-day return policy on unopened items.' },
  ];

  return (
    <div>
      {/* Breadcrumb */}
      <div className="container" style={{ padding: '16px var(--side)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <button onClick={onBack} style={{
            background: 'none', border: 'none', cursor: 'pointer',
            fontFamily: 'var(--font-ui)', fontSize: '0.8125rem', color: 'var(--ink-500)',
          }}>Home</button>
          <span style={{ color: 'var(--ink-500)', fontSize: '0.75rem' }}>/</span>
          <span style={{ fontSize: '0.8125rem', color: 'var(--ink-500)' }}>{product.brand}</span>
          <span style={{ color: 'var(--ink-500)', fontSize: '0.75rem' }}>/</span>
          <span style={{ fontSize: '0.8125rem', color: 'var(--ink-900)' }}>{product.name}</span>
        </div>
      </div>

      {/* Main PDP */}
      <div className="container" style={{ borderTop: '1px solid var(--line)' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 48, padding: '40px 0' }} className="pdp-grid">
          {/* Left: Image Gallery */}
          <div style={{ display: 'flex', gap: 12 }}>
            {/* Thumbnails */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, flexShrink: 0 }}>
              {images.map(idx => (
                <div key={idx} onClick={() => setSelectedImage(idx)}
                  className="img-placeholder" style={{
                    width: 56, height: 56, borderRadius: 'var(--radius-card)', cursor: 'pointer',
                    border: selectedImage === idx ? '2px solid var(--ink-900)' : '2px solid var(--line)',
                    fontSize: '0.5rem', transition: 'border-color 150ms',
                  }}>
                  {idx + 1}
                </div>
              ))}
            </div>
            {/* Main image */}
            <div className="img-placeholder" style={{
              flex: 1, aspectRatio: '4/5', borderRadius: 'var(--radius-card)',
            }}>
              <span>product image {selectedImage + 1}</span>
            </div>
          </div>

          {/* Right: Product Info */}
          <div>
            <Overline style={{ display: 'block', marginBottom: 8, color: 'var(--ink-500)' }}>{product.brand}</Overline>
            <h1 style={{
              fontFamily: 'var(--font-display)', fontSize: '2.5rem', fontWeight: 500,
              letterSpacing: '-0.025em', lineHeight: 1.1, marginBottom: 8,
            }}>{product.name}</h1>
            {product.variant && (
              <div className="body-text" style={{ color: 'var(--ink-500)', marginBottom: 16 }}>{product.variant}</div>
            )}

            {/* Price */}
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, marginBottom: 24 }}>
              <span className="tabular-nums" style={{ fontSize: '1.5rem', fontWeight: 600 }}>PKR {product.price.toLocaleString()}</span>
              {product.originalPrice && (
                <span className="tabular-nums" style={{
                  textDecoration: 'line-through', color: 'var(--brand-pink)', fontSize: '1rem'
                }}>PKR {product.originalPrice.toLocaleString()}</span>
              )}
            </div>

            <hr className="hairline" style={{ marginBottom: 24 }} />

            {/* Quantity + Add to Cart */}
            <div style={{ display: 'flex', gap: 12, marginBottom: 24 }}>
              <div style={{
                display: 'flex', alignItems: 'center', border: '1px solid var(--line)',
                borderRadius: 'var(--radius-card)',
              }}>
                <button onClick={() => setQty(Math.max(1, qty - 1))} style={{
                  width: 40, height: 44, background: 'none', border: 'none', cursor: 'pointer',
                  fontSize: '1rem', color: 'var(--ink-700)',
                }}>−</button>
                <span style={{ width: 32, textAlign: 'center', fontWeight: 500, fontVariantNumeric: 'tabular-nums' }}>{qty}</span>
                <button onClick={() => setQty(qty + 1)} style={{
                  width: 40, height: 44, background: 'none', border: 'none', cursor: 'pointer',
                  fontSize: '1rem', color: 'var(--ink-700)',
                }}>+</button>
              </div>
              <button onClick={handleAdd} className="btn-primary" style={{
                flex: 1,
                background: addedFlash ? 'var(--brand-yellow)' : 'var(--brand-pink)',
                transition: 'background 100ms ease-out',
              }}>
                {addedFlash ? 'Added ✓' : 'Add to Cart'}
              </button>
            </div>

            {/* Short description */}
            <p className="body-text" style={{ color: 'var(--ink-700)', marginBottom: 24, maxWidth: 440 }}>
              A high-coverage, crease-resistant formula that blends effortlessly for a natural, flawless finish. Imported and 100% authentic.
            </p>

            <hr className="hairline" style={{ marginBottom: 0 }} />

            {/* Expandable sections */}
            {expandables.map(sec => (
              <div key={sec.key} style={{ borderBottom: '1px solid var(--line)' }}>
                <button onClick={() => setExpandedSection(expandedSection === sec.key ? null : sec.key)}
                  style={{
                    width: '100%', padding: '16px 0', background: 'none', border: 'none', cursor: 'pointer',
                    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                    fontFamily: 'var(--font-ui)', fontSize: '0.875rem', fontWeight: 600, color: 'var(--ink-900)',
                  }}>
                  {sec.title}
                  <span style={{
                    transform: expandedSection === sec.key ? 'rotate(180deg)' : 'rotate(0)',
                    transition: 'transform 200ms ease-out', fontSize: '0.75rem',
                  }}>▼</span>
                </button>
                {expandedSection === sec.key && (
                  <div className="body-text" style={{ color: 'var(--ink-700)', paddingBottom: 16 }}>
                    {sec.content}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Editorial story block */}
      <section style={{
        background: 'var(--paper2)', padding: 'var(--section-gap) 0',
        borderTop: '1px solid var(--line)', borderBottom: '1px solid var(--line)',
      }}>
        <div className="container" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 48, alignItems: 'center' }} className="container story-grid">
          <div className="img-placeholder" style={{ aspectRatio: '4/3', borderRadius: 'var(--radius-card)' }}>
            <span>editorial lifestyle photo</span>
          </div>
          <div>
            <Overline style={{ display: 'block', marginBottom: 12, color: 'var(--ink-500)' }}>The Story</Overline>
            <h2 className="display-l" style={{ fontSize: '2rem', marginBottom: 16 }}>
              Why {product.name}?
            </h2>
            <p className="body-text" style={{ color: 'var(--ink-700)', marginBottom: 16, maxWidth: 440 }}>
              Every product we carry has been tested, reviewed, and chosen for Pakistani skin tones and climates. We don't carry what doesn't work.
            </p>
            <p className="body-text" style={{ color: 'var(--ink-700)', maxWidth: 440 }}>
              Imported directly from authorized distributors. No fakes, no compromises.
            </p>
          </div>
        </div>
      </section>

      {/* Pairs With */}
      <section style={{ padding: 'var(--section-gap) 0' }}>
        <div className="container">
          <Overline style={{ display: 'block', marginBottom: 32 }}>Pairs With</Overline>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 'var(--gutter)' }} className="product-grid">
            {[
              { brand: 'Pixi', name: 'On-the-Glow Blush', variant: 'Fleur', price: 3400 },
              { brand: 'SHEGLAM', name: 'Color Bloom Blush', variant: 'Risky Business', price: 1200 },
              { brand: 'Iconic London', name: 'Liquid Highlighter', variant: 'Original', price: 4800 },
              { brand: 'CeraVe', name: 'Moisturizing Cream', variant: '340g', price: 3900 },
            ].map((p, i) => <ProductTile key={i} {...p} />)}
          </div>
        </div>
      </section>
    </div>
  );
};

Object.assign(window, { PDPPage });
