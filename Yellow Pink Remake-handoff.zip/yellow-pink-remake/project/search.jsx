/* Yellow Pink — Search Overlay */

const SearchOverlay = ({ open, onClose }) => {
  const [query, setQuery] = React.useState('');
  const [focused, setFocused] = React.useState(false);
  const inputRef = React.useRef(null);

  React.useEffect(() => {
    if (open && inputRef.current) {
      setTimeout(() => inputRef.current.focus(), 100);
    }
    if (!open) setQuery('');
  }, [open]);

  // Close on Escape
  React.useEffect(() => {
    const fn = (e) => { if (e.key === 'Escape' && open) onClose(); };
    window.addEventListener('keydown', fn);
    return () => window.removeEventListener('keydown', fn);
  }, [open, onClose]);

  const allProducts = window.__ALL_PRODUCTS || [];
  const filtered = query.length > 0
    ? allProducts.filter(p =>
        (p.name + ' ' + p.brand + ' ' + (p.variant || '') + ' ' + (p.category || ''))
          .toLowerCase().includes(query.toLowerCase())
      )
    : [];

  const trending = ['CeraVe', 'Rhode Lip Tint', 'Melasma Cream', 'NARS Foundation', 'Tarte Concealer'];
  const popularCats = ['Skincare', 'Lip Tints', 'Foundations', 'Sunscreen', 'Wellness'];

  return (
    <>
      <div onClick={onClose} style={{
        position: 'fixed', inset: 0, background: 'rgba(10,10,10,0.5)',
        opacity: open ? 1 : 0, pointerEvents: open ? 'auto' : 'none',
        transition: 'opacity 200ms ease-out', zIndex: 300,
      }}></div>
      <div style={{
        position: 'fixed', top: 0, left: 0, right: 0,
        background: 'var(--paper)', zIndex: 301,
        transform: open ? 'translateY(0)' : 'translateY(-100%)',
        transition: 'transform 300ms ease-out',
        boxShadow: 'var(--shadow-1)',
        maxHeight: '80vh', overflowY: 'auto',
      }}>
        <div className="container" style={{ padding: '24px var(--side)' }}>
          {/* Search input */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: 12,
            borderBottom: '2px solid var(--ink-900)', paddingBottom: 12, marginBottom: 24,
          }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--ink-500)" strokeWidth="2" strokeLinecap="round">
              <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
            </svg>
            <input
              ref={inputRef}
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search products, brands, concerns..."
              style={{
                flex: 1, border: 'none', outline: 'none', background: 'transparent',
                fontFamily: 'var(--font-ui)', fontSize: '1.125rem', fontWeight: 400,
                color: 'var(--ink-900)',
              }}
            />
            <button onClick={onClose} style={{
              background: 'none', border: 'none', cursor: 'pointer',
              color: 'var(--ink-500)', fontSize: '0.8125rem', fontWeight: 500, fontFamily: 'var(--font-ui)',
            }}>Close</button>
          </div>

          {/* Results or suggestions */}
          {query.length > 0 ? (
            <div>
              {filtered.length === 0 ? (
                <p className="body-text" style={{ color: 'var(--ink-500)', padding: '16px 0' }}>
                  No results for "{query}". Try a different search term.
                </p>
              ) : (
                <div>
                  <Overline style={{ display: 'block', marginBottom: 12, color: 'var(--ink-500)' }}>
                    {filtered.length} Result{filtered.length !== 1 ? 's' : ''}
                  </Overline>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
                    {filtered.slice(0, 6).map((p, i) => (
                      <div key={i} style={{
                        display: 'flex', alignItems: 'center', gap: 12,
                        padding: '12px 0', borderBottom: '1px solid var(--line)',
                        cursor: 'pointer',
                      }}
                        onMouseEnter={e => e.currentTarget.style.background = 'var(--paper2)'}
                        onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                      >
                        <div className="img-placeholder" style={{
                          width: 48, height: 48, borderRadius: 'var(--radius-card)', flexShrink: 0, fontSize: '0.5rem'
                        }}>img</div>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <Overline style={{ color: 'var(--ink-500)', fontSize: '0.5625rem', display: 'block' }}>{p.brand}</Overline>
                          <div style={{ fontSize: '0.875rem', fontWeight: 600 }}>{p.name}</div>
                        </div>
                        <span className="tabular-nums" style={{ fontWeight: 600, fontSize: '0.875rem', flexShrink: 0 }}>
                          PKR {p.price.toLocaleString()}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 40 }} className="search-suggestions">
              <div>
                <Overline style={{ display: 'block', marginBottom: 12, color: 'var(--ink-500)' }}>Trending</Overline>
                {trending.map((t, i) => (
                  <div key={i}
                    onClick={() => setQuery(t)}
                    style={{
                      padding: '8px 0', cursor: 'pointer',
                      fontSize: '0.9375rem', color: 'var(--ink-700)',
                      borderBottom: '1px solid var(--line)',
                    }}
                    onMouseEnter={e => e.currentTarget.style.color = 'var(--ink-900)'}
                    onMouseLeave={e => e.currentTarget.style.color = 'var(--ink-700)'}
                  >{t}</div>
                ))}
              </div>
              <div>
                <Overline style={{ display: 'block', marginBottom: 12, color: 'var(--ink-500)' }}>Categories</Overline>
                {popularCats.map((c, i) => (
                  <div key={i}
                    onClick={() => setQuery(c)}
                    style={{
                      padding: '8px 0', cursor: 'pointer',
                      fontSize: '0.9375rem', color: 'var(--ink-700)',
                      borderBottom: '1px solid var(--line)',
                    }}
                    onMouseEnter={e => e.currentTarget.style.color = 'var(--ink-900)'}
                    onMouseLeave={e => e.currentTarget.style.color = 'var(--ink-700)'}
                  >{c}</div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

Object.assign(window, { SearchOverlay });
